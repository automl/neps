error_message = "Please install torch (and torch_geometric)! We provide a script for installation with python -m neps.utils.install_torch"
